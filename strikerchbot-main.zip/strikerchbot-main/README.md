# MRBANKER BOT
___
A telegram bot to check credit cards. written in py.
You can find me on [telegram](https://telegram.me/MrBankerBot)

## STEP1:
goto botfather create a bot copy the token paste at the time of deployment.
___
Note: This adblocker needs fresh proxies per req...
___

## Click below deploy button to host it on heroku.
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

You can contact me [tg](https://telegram.me/nitin181) my tg channel [here](https://telegram.me/binverse)
Feel free to donate me ..
